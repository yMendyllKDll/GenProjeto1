package org.generation.brazil;

public class Login {
 
	public String nome;
	public int senha;
	public String login;
	public int dataNascimento;
	   
	   public String getNome() {
		   return nome;
	   }
	   
	   public void setNome(String name) {
		   nome = name;
	   }
	   
	   public String getLogin() {
		   return login;
	   }
	   
	   public void setLogin(String login) {
		   login = login;
	   }
	   
	   public int getDataNascimento() {
		   return dataNascimento;
	   }
	   
	   public void setDataNascimento(int dataNascimento) {
		   dataNascimento = dataNascimento;
	   }
	     
}