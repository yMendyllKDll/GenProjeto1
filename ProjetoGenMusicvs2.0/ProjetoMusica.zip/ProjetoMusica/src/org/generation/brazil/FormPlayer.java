package org.generation.brazil;

public class FormPlayer implements Player {

	private int iniciar = 0;
	
	@Override
	public void iniciar() {

		System.out.println("\n⏮ ▶️ ⏸️ ⏹️ ⏭️");
	
	}
}