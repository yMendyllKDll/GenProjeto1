package org.generation.brazil;

public interface Player {
	
	public abstract void iniciar();
	
	
}